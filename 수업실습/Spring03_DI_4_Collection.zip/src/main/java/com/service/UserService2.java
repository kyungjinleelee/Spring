package com.service;

import java.util.List;
import java.util.Set;

import com.dto.Cat;

public class UserService2 {

	// 여러 데이터를 받으니까 list (한 마리가 아닌 여러 마리)
	Set<Cat> catSet;

	public Set<Cat> getCatSet() {
		return catSet;
	}

	public void setCatSet(Set<Cat> catSet) {
		this.catSet = catSet;
	}
	
	
	
	
	
	
}
