package com.service;

public class UserService_Dev implements UserService {

	@Override
	public String mesg() {
		return "UserService_Dev 환경";
	}

	
}
