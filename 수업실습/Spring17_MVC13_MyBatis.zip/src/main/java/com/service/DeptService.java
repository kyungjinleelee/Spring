package com.service;

import java.util.List;

import com.dto.DeptDTO;

public interface DeptService {

	// ��Ϻ���
	public List<DeptDTO> findAll();
	// �μ� ��� 
	public int deptAdd(DeptDTO dto);
}
