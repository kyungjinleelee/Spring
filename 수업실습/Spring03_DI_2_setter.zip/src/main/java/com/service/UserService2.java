package com.service;

public class UserService2 {

	int num;
	String username;
	
	// setter 메서드 이용한 의존성 주입
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		System.out.println("setUsername 메서드");
		this.username = username;
	}
	
	
	// setter 메서드 이용한 의존성 주입 
	
	
}
