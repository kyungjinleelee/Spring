package com.sparta.newsfeed.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/api")
public class UserController {

 //   private final MemberService memverService;

    // 로그인 페이지
    @GetMapping("/user/login-page")
    public String loginPage() {
        return "login";
    }

    // 회원가입 페이지
    @GetMapping("user/signup")
    public String signupPage(){
        return "signup";
    }

//    // 회원 가입
//    @PostMapping("/members")
//    @ResponseBody
//    public Long saveMember() {
//
//    }

}
