package com.dao;

public class UserDAO {

	public UserDAO() {
		System.out.println("UserDAO 생성자");
	}
	// 이제 빈 생성하러 가자! => user.xml 가서  등록
}
