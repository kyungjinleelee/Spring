import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.dto.Cat;
import com.dto.Person;

public class TestMain {

	public static void main(String[] args) {

		ApplicationContext ctx
		 = new GenericXmlApplicationContext("classpath:com/config/user.xml");
		
	// 1. 전체 Cat 목록
		Person p1 = ctx.getBean("p1", Person.class);
		List<Cat> catList = p1.getCatList();
		for(Cat cat : catList) {
			System.out.println(cat);
		//	Person [username=야옹이1, age=2, isMarried=true, height=45.4]
		//	Person [username=야옹이2, age=12, isMarried=false, height=15.6]
		//	Person [username=야옹이3, age=7, isMarried=false, height=25.6]
		//	Person [username=야옹이4, age=3, isMarried=false, height=145.4]
		}
		
	// 2. idx 이용한 특정 위치의 Cat 출략
		Person p2 = ctx.getBean("p2", Person.class);
		List<Cat> catList2 = p2.getCatList();
		for(Cat cat : catList2) {
			System.out.println(cat); 
			// Person [username=야옹이1, age=2, isMarried=true, height=45.4]
		}
	
	// 3. age < 10 Cat 출력 (조건이 있음)
		Person p3 = ctx.getBean("p3", Person.class);
		List<Cat> catList3 = p3.getCatList();
		for(Cat cat : catList3) {
			System.out.println(cat); // age가 10보다 작은 값 3개 나옴
		}
		
	// 4. age < 10 and married == false Cat 출력 (조건이 여러개)
		Person p4 = ctx.getBean("p4", Person.class);
		List<Cat> catList4 = p4.getCatList();
		for(Cat cat : catList4) {
			System.out.println(cat); // 조건에 맞는 값 2개 나옴 
		}
	}

}
