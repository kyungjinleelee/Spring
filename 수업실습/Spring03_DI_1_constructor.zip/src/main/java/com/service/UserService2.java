package com.service;

public class UserService2 {
	
	// 두 가지 변수를 설정
	int num;
	String username; 

	public UserService2() {
		System.out.println("UserService 기본생성자");
	}
	// 생성자 이용해서 주입
	public UserService2(int num, String username) {
		System.out.println("UserService(int num, String Username) 생성자");
		this.num = num;
		this.username = username;
	}

	// 메서드 만들기
	public int getNum() {
		return num;
		}
	public String getUsername() {
		return username;
	}
	
	
}
