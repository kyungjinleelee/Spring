package com.dto;

import java.util.List;

public class Person {

	List<Cat> catList;

	public List<Cat> getCatList() {
		return catList;
	}

	public void setCatList(List<Cat> catList) {
		this.catList = catList;
	}
	
	
}
