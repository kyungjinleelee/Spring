package com.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


@Controller 
public class TestController {
	
	
	// redirect�� ��û 
	@RequestMapping("/aaa")
	public String aaa(Model m) {
		System.out.println("aaa ȣ��");
		m.addAttribute("userid", "ȫ�浿");
		return "redirect:xxx";
	}
	
	// flash scope redirect�� ��û 
		@RequestMapping("/bbb")
		public String bbb(RedirectAttributes m) {
			System.out.println("bbb");
			m.addFlashAttribute("userid", "ȫ�浿");
			return "redirect:xxx";
		}
	
		@RequestMapping("/xxx")
		public String main() {
			System.out.println("main ȣ��");
			return "main";
		}
}
