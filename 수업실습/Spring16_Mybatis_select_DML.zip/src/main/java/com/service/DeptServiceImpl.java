package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.dao.DeptDAO;
import com.dto.DeptDTO;

// @Component("service") // @component 이름 줄 수 있음  (필수 아님)
@Service("service")
public class DeptServiceImpl implements DeptService{

	@Autowired
	DeptDAO dao;

	// 스프링에서는 DML 작업 시 자동으로 commit 된다. (오토커밋) -> 따로 session.commmit 안해줘도 됨
	@Override
	public List<DeptDTO> findAll() {
		return dao.findAll();
	}

	@Override
	public int deptAdd(DeptDTO dto) {
		return dao.deptAdd(dto);
	}

	@Override
	public int deptUpdate(DeptDTO dto) {
		return dao.deptUpdate(dto);
	}

	@Override
	public int deptDelete(int deptno) {
		return dao.deptDelete(deptno);
	}

	
	
}
