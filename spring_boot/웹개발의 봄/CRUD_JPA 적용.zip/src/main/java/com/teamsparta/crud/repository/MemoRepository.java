package com.teamsparta.crud.repository;

import com.teamsparta.crud.entity.Memo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

// @Repository 없어도 무방함 > 트랜잭셔널에서 구현체를 자동으로 만들어주고, bean으로 만들어 주기 때문
@Repository // 빈 객체로 등록 (@Component와 동일)(스프링이 run 될 때 IOC Container에 이 클래스를 빈으로 만들어서 등록해줌)
public interface MemoRepository extends JpaRepository<Memo, Long> {



}