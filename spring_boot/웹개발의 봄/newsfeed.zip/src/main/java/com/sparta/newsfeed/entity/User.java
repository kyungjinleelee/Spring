package com.sparta.newsfeed.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // auto incrememt
    private Long id;         // PK 아이디

    @Column(nullable = false, unique = true)    // null값 불가에 중복 허용
    private String username; // 로그인용 아이디

    @Column(nullable = false)
    private String password; // 로그인용 패스워드

    @Column(nullable = false)
    private String name;     // 실제 이름

    @Column(nullable = false, unique = true)
    private String email;    // 이메일

    @Column(nullable = false)
    @Enumerated(value = EnumType.STRING)    // EnumType을 DB컬럼에 저장할 때 사용
    private UserRoleEnum role;
}
