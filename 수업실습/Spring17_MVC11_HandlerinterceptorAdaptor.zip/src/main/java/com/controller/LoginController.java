package com.controller;

import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dto.LoginDTO;

@Controller 
public class LoginController {
	
	@GetMapping("/loginForm")
	public String home() {
		return "loginForm"; // /WEB-INF/views/loginForm.jsp �� ������ ��û�ȴ�.
	}
	
	@GetMapping("/login")
	public String login(LoginDTO dto, HttpSession session) { 
		//����� ������ �̿��ؼ� DB �����ؼ� ����.
		// ���ǿ� ����
		session.setAttribute("login", dto);
		return "login";  // /WEB-INF/views/login.jsp 
	}
	
	@GetMapping("/loginCheck/logout")
	public String logout(HttpSession session) {
			session.invalidate();
			return "main"; 
	}
	
	@GetMapping("/mypage")
	public String mypage() {
		
		return "main"; // /WEB-INF/views/loginForm.jsp �� ������ ��û�ȴ�.
	}


}
