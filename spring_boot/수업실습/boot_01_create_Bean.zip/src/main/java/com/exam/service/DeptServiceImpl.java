package com.exam.service;

import org.springframework.stereotype.Service;

@Service
public class DeptServiceImpl {

	public DeptServiceImpl() {
		System.out.println("DeptServiceImpl 생성");
	}

}
