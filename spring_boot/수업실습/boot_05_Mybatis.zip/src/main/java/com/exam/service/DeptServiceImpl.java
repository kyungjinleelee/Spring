package com.exam.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exam.dao.DeptDAO;
import com.exam.dto.DeptDTO;

@Service("xxx")
public class DeptServiceImpl implements DeptService {
	
	@Autowired
	DeptDAO dao; // dao 주입 

	@Override
	public List<DeptDTO> deptList() {
		return dao.deptList();
	}
	
}
