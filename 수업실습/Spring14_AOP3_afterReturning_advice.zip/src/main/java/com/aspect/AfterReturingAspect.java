package com.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

// target인 UserService의 sayEcho() 메서드 호출 시 위빙되는 aspect 객체

@Aspect
public class AfterReturingAspect { // after, before와 달리 메서드 호출 후 리턴값을 받을 수 있음

	@Pointcut("execution(public String sayEcho())") // sayEcho() 메서드 호출
	public void xxx() {}
	
	// afterReturning어드바이스는 파라미터값을 object로 받아야함
	@AfterReturning(pointcut="xxx()", returning="xxx") // returning 속성에 sayEcho() 메서드가 리턴하는 값이 저장될 변수를 지정
	public void method2(Object xxx) {  // 위의 sayEco() 메서드가 가 리턴하는 String 값을 xxx에 저장 
		System.out.println("AfterReturning.method2 " + xxx); // hello
		// sayEcho() 호출해서 정상적으로 리턴값을 리턴했을 때 위빙된다.
	}
	

	// advice + pointcut 같이 표현 / JoinPoint 기능
	@AfterReturning(pointcut="execution(* callEcho(..))", returning="yyy") // callEcho 호출 후에 실행됨
	public void method3(JoinPoint point, Object yyy) {
		System.out.println("호출한 핵심기능 메서드명:" + point.getSignature().getName()); // callEcho
		System.out.println("AfterReturning.method3 " + yyy); // world
	}
}
