import org.springframework.context.support.GenericXmlApplicationContext;

public class UserMain2 {

	public static void main(String[] args) {

		GenericXmlApplicationContext ctx = 
				new GenericXmlApplicationContext("classpath:com/config/user2.xml");
		
		ctx.close(); // <== close()시  DisposableBean.destroy() 메서드 호출 됨
		
	}

}
