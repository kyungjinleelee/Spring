package com.service;

public class UserService {

	public String username;
	
	public UserService() {
		System.out.println("UserService 기본 생성자");
	} // 기본 생성자만 만들어두기

	
}
