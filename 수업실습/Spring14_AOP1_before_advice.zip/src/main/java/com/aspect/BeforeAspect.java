package com.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

// target인 UserService의 sayEcho() 메서드 호출 시 위빙되는 aspect 객체

@Aspect
public class BeforeAspect {

	@Pointcut("execution(public String sayEcho())") // sayEcho() 메서드 호출
//	@Pointcut("execution(public String *Echo())") // *Echo() (아무거나 Echo) 메서드 호출
	public void xxx() {}
	
	@Before("xxx()") // pointcut에 있는 메서드 이름 연결해주기
	public void method2() { // 진짜 실행되어야 할 메서드 
		System.out.println("BeforeAspect.method2"); // sayEcho() 호출 전에 실행됨
	}
	
	// advice + pointcut 같이 표현
	@Before("execution(* callEcho(..))")
	public void method3() {
		System.out.println("BeforeAspect.method3");
	}
}
