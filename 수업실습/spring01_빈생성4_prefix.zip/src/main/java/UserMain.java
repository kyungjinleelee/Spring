import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.service.UserService;

public class UserMain {

	public static void main(String[] args) {

		// 1. 이전 방식 
//		UserService service = new UserService();
//		System.out.println(service.mesg());
		
		// 2. 스프링 방식
		// 파일로 있는 xml 주소 명시할 시 "file:~" 꼭 붙여주기
		ApplicationContext ctx = 
				new GenericXmlApplicationContext("classpath:com/config/user.xml", 
												 "file:c:\\spring_study\\user2.xml");
	}

}


