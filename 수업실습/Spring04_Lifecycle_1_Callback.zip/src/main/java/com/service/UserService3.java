package com.service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class UserService3 {

	public UserService3() {
		System.out.println("UserService3 기본 생성자");
	}
	
	// 어노테이션을 이용한 방법  ==> 어노테이션 활성화 필수 (context namespace 이용)
			// <context:annotation-config />
	@PostConstruct
	public void xxx() {
		System.out.println("생성자 후 @PostConstruct.xxx");
	}
	
	@PreDestroy
	public void yyy() {
		System.out.println("@PreDestroy.yyy");
	}
	
}
