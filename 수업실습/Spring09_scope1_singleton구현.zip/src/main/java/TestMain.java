
// 자바의 싱글톤 패턴 구현 (singleton design pattern)
// UserService를 한 번만 생성하게끔 구현
class UserService{
	// 3. static 변수로 지정 (getInstance 메서드 외부에서 사용해야하기 때문에)
	static UserService service;
	// 1. 생성자를 private으로 지정 (외부에서 생성 못하게끔)
	private UserService() {	
	}
	
	// 2. 자기 자신 메서드 안에서 생성 (객체 생성하고 접근할 필요 없도록 static 지정)
	public static UserService getInstance() {
		// 4. if문 작성 
		// 맨 처음 getInstance() 호출하면 null이기 때문에 if문이 실행되어 객체생성이 되고 service 변수에 100번지가 저장된다.
		// 두 번째 getInstance() 호출부터는 null이 아니기 때문에 if문 실행 안되어 객체생성없이 그냥 service 값인 100번지를 반환한댜.
		if(service==null) {
			service = new UserService();
		}
		return service;
	}
}
public class TestMain {

	public static void main(String[] args) {
		
		UserService s1 = UserService.getInstance();
		UserService s2 = UserService.getInstance();
		UserService s3 = UserService.getInstance();
		
		System.out.println(s1 == s2);
		System.out.println(s1 == s2);
		System.out.println(s1 == s2); // 주소값을 찍어보면 다 똑같이 나옴.(true)
	}

}
