package com.exam.controller;

import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.exam.dto.DeptDTO;

@Controller
public class TestController {

	/* 
	     기존 SpringFramework의  application scope 사용
	   1) implements ServletContextAware
	   2) @Override
	public void setServletContext(ServletContext servletContext) {
		this.application = servletContext;
	}
	*/
	
	@Autowired
	ServletContext application;
	
	@GetMapping("/main")
	public String main() {
		return "main"; // src/main/resources/templates/main.html
	}
	
	@GetMapping("/main2")
	public String main2(Model m, HttpSession session) { // 모델 저장 후 html에서 보여주기
		m.addAttribute("username", "홍길동" ); // request scope에 저장됨 (model의 디폴트값)
		session.setAttribute("username", "홍길동2"); // session에 저장됨
		application.setAttribute("username", "홍길동3"); // application에 저장됨
		return "main2"; 
	}
	
	@GetMapping("/main3")
	public String main3(Model m) { // DTO 실습
		m.addAttribute("DeptDTO", 
				new DeptDTO(2, "개발", "서울"));
		return "main3"; 
	}
	
	@GetMapping("/main4")
	public String main4(Model m) { // 조건문 실습 
		m.addAttribute("DeptDTO", 
				new DeptDTO(2, "개발", "서울"));
		m.addAttribute("DeptDTO2", 
				new DeptDTO(2, null, "서울"));
		
		List<DeptDTO> list = 
				Arrays.asList(new DeptDTO(10, "개발부","서울시"),
						new DeptDTO(20, "인사부","대전시"),
						new DeptDTO(30, "마케팅부","서울시"));
		m.addAttribute("deptList", list);
		return "main4"; 
	}
	
	@GetMapping("/main5")
	public String main5(Model m) {
		m.addAttribute("DeptDTO",
				new DeptDTO(20, "개발", "서울"));
		return "main5"; 
	}
	
	@GetMapping("/main5_1")
	public String main5_1(
			@RequestParam("id") String id,
			@RequestParam("age") String age) {
		return "main5"; 
	}
	
	@GetMapping("/main6")
	public String main6() {
		return "main6"; 
	}
}
