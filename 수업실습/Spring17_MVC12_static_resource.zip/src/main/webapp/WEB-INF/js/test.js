function fun(){
	alert("fun");
}