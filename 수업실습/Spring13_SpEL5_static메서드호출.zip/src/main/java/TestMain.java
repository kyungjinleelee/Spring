import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.dto.Person;

public class TestMain {

	public static void main(String[] args) {

		ApplicationContext ctx
		 = new GenericXmlApplicationContext("classpath:com/config/user.xml");
		
		Person p = ctx.getBean("p1", Person.class);
		System.out.println(p); // p1의 메서드와 나머지값들을 출력
		// Person [username=LeeSunShin, ~나머지 설정값들]
		
	}

}
