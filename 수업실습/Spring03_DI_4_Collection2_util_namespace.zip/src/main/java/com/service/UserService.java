package com.service;

import java.util.List;

import com.dto.Cat;

public class UserService {

	// 여러 데이터를 받으니까 list (한 마리가 아닌 여러 마리)
	List<Cat> catList;

	public List<Cat> getCatList() {
		return catList;
	}

	// 데이터 주입하면서 setter 메서드 이용
	public void setCatList(List<Cat> catList) {
		this.catList = catList;
	}
	
	
}
