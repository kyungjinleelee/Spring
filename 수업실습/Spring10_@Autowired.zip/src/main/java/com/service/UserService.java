package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.dao.UserDAO;

public class UserService {

	@Autowired
	UserDAO dao; // 변수에 autowired를 지정하면 다른 메서드나 생성자가 필요없다.
	

//	public UserService() {} // 기본 생성자 만들어줘야 빈 등록할 때 에러 안남
//
//	public UserService(UserDAO dao) {
//		System.out.println("UserService(UserDAO dao)");
//		this.dao = dao;
//	}
//
//
//	public void setDao(UserDAO dao) {
//		System.out.println("setDao(UserDAO dao)");
//		this.dao = dao;
//	}
//	
	public List<String> list(){
		return dao.list();
	}
}
