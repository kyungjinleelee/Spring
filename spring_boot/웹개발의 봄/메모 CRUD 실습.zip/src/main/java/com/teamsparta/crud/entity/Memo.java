package com.teamsparta.crud.entity;

import com.teamsparta.crud.dto.MemoRequestDto;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor  // 기본생성자 만들어주는 @
public class Memo {
    private Long id;        // 메모장 ID
    private String username; // 메모 작성한 사람
    private String contents; // 메모 내용

    public Memo(MemoRequestDto requestDto) {
        this.username = requestDto.getUsername();
        this.contents = requestDto.getContents();
    }

    public void update(MemoRequestDto requestDto) { // 업데이트
        this.username = requestDto.getUsername();
        this.contents = requestDto.getContents();
    }
}