package com.service;

public class UserService {

	public UserService() {
		System.out.println("UserService 기본 생성자");
	}

	// init-method="xxx" 콜백 메서드 만들기
		// 리턴타입 : void, 인자값 없어야함
	public void xxx() {
		System.out.println("생성자 호출 후 xxx 호출");
	}
	
	// destroy-method="yyy" 콜백 메서드 만들기
	public void yyy() {
		System.out.println("yyy 호출");
	}
}
