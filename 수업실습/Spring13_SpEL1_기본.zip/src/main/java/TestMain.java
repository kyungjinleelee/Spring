import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.dto.Person;

public class TestMain {

	public static void main(String[] args) {

		ApplicationContext ctx
		 = new GenericXmlApplicationContext("classpath:com/config/user.xml");
		
		Person p = ctx.getBean("p2", Person.class);
		System.out.println(p); // Person p가 갖고있는 정보들이 출력
		//Person [username=이순신, age=3, isMarried=true, height=178.2]
		// ==> user.xml에서 #{}로 주입해 준 값이 나옴
	}

}
