package com.service;

import java.util.List;

public interface DeptService {
	public List<String> list();
}
