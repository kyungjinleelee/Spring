import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.service.UserService;

public class UserMain {

	public static void main(String[] args) {

		// 1. 이전 방식 
//		UserService service = new UserService();
//		System.out.println(service.mesg());
		
		// 2. 스프링 방식
//		ApplicationContext ctx = 
//				new GenericXmlApplicationContext("com/config/user.xml");
		// 이 경우 user.xml만 생성 되고 user2.xml은 안됨
			// => 쉼표 찍고 두 개 xml 다 생성해주기
		ApplicationContext ctx = 
				new GenericXmlApplicationContext("com/config/user.xml", "com/config/user2.xml");
	}
/*		ApplicationContext ctx = 
			new GenericXmlApplicationContext("com/config/*.xml"); 이렇게 *.xml로 해줘도 됨 (가독성은 떨어짐)
*/
}


