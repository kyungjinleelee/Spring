package com.controller;

import java.util.Arrays;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.dto.LoginDTO;

@Controller 
public class LoginController {
	
	@GetMapping("/loginForm")
	public String home() { 
		return "loginForm"; // InternalResourceViewResolver�� ���ؼ� /WEB-INF/views/loginForm.jsp�� ������ ��û��
	}
	
	@GetMapping("/login")
	public String login(LoginDTO dto) { 
		System.out.println(dto); // LoginDTO [userid=lee2994, passwd=12, phone=[01011112222, 01055554444], email=[12@naver.com, 13@naver.com]]

		return "loginForm";  
	}
	
	
// ���� ������ ��� 
	@GetMapping("/login2")
	public String login2(HttpServletRequest request) { 
		// ����� �Է� ������ ���
		String userid = request.getParameter("userid");
		String passwd = request.getParameter("passwd");
		
		String [] phone = request.getParameterValues("phone");
		String [] email = request.getParameterValues("email");
		
		System.out.println(userid + " " + passwd);
		System.out.println(Arrays.toString(phone)+" "
						  + Arrays.toString(email));
		return "loginForm";  
	}
	
}
