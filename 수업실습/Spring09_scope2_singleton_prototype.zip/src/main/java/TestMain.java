import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.service.UserService;

public class TestMain {

	public static void main(String[] args) {

		ApplicationContext ctx = 
				new GenericXmlApplicationContext("classpath:com/config/user.xml");
		// singleton은 하나의 인스턴스로 여러 사용자가 사용하기 때문에 공유됨
			// ==> UserService에서 선언한 username 변수를 공유한다는 뜻
		UserService s1 = ctx.getBean("service", UserService.class);
		UserService s2 = ctx.getBean("service", UserService.class);
		System.out.println("singleton:" + (s1 == s2)); // true
	
		s1.username = "홍길동";
		s2.username = "이순신";
		
		System.out.println(s1.username + "\t" + s2.username); // 이순신 이순신 
		
		// prototype은 매번 새로 생성됨 => 자신만의 데이터 유지 가능
		UserService s3 = ctx.getBean("service2", UserService.class);
		UserService s4 = ctx.getBean("service2", UserService.class);
		System.out.println("prototype:" + (s3 == s4)); // false
	
		s3.username = "유관순";
		s4.username = "강감찬";
		System.out.println(s3.username + "\t" + s4.username); // 유관순 강감찬
	}

}
