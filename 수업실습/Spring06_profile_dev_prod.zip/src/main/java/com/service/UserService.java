package com.service;

public interface UserService {

	public String mesg();
}
