package com.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;


@Controller 
public class TestController {
	
	// http://localhost:8090/app
	@GetMapping("/")
	public String home() { 
		
		return "main"; 
	}
	
	
	
}
