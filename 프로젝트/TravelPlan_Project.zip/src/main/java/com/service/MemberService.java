package com.service;

public interface MemberService {
	
}
