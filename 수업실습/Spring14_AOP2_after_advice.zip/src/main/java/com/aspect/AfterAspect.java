package com.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

// target인 UserService의 sayEcho() 메서드 호출 시 위빙되는 aspect 객체

@Aspect
public class AfterAspect {

	@Pointcut("execution(public String sayEcho())") // sayEcho() 메서드 호출
	public void xxx() {}
	
	@After("xxx()") // pointcut에 있는 메서드 이름 연결해주기
	public void method2() { // 진짜 실행되어야 할 메서드 
		System.out.println("AfterAspect.method2"); // sayEcho() 호출 후에 실행됨
	}
	
	// advice + pointcut 같이 표현 / JoinPoint 기능(필수 아님)
	@After("execution(* callEcho(..))") // callEcho 호출 후에 실행됨
	public void method3(JoinPoint point) {
		System.out.println("호출한 핵심기능 메서드명:" + point.getSignature().getName()); // callEcho
		System.out.println("AfterAspect.method3");
	}
}
