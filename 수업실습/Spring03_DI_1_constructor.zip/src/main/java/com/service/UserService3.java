package com.service;

import java.util.List;
import com.dao.UserDAO;

public class UserService3 {
	// 주입 받아야 하는 데이터
	UserDAO dao;
	public int num;
	
	public UserService3(UserDAO dao, int num) {
		this.dao = dao;
		this.num = num; // 생성자 만들기
	}
	
	public UserService3(UserDAO dao) {
		this.dao = dao;
	}
	
	public List<String> list(){
		return dao.list();
	}
	
}
