package com.dto;

import org.springframework.beans.factory.annotation.Value;

public class Cat {

	@Value(value = "${cat.username}") // 값을 주입하고 싶을 때 @Value 태그 
	String username;
	
	@Value(value = "${cat.age}")   // 값은 무조건 ""로 감싸서 넣어줘야함 (자동 형변환)
	int age;
	
	public Cat() {}
	
	public Cat(String username, int age) {
		super();
		this.username = username;
		this.age = age;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	@Override
	public String toString() {
		return "Cat [username=" + username + ", age=" + age + "]";
	}
	
	
}
