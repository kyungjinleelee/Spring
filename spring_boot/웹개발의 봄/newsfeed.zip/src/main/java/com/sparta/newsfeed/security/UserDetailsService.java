package com.sparta.newsfeed.security;

public interface UserDetailsService {
}
