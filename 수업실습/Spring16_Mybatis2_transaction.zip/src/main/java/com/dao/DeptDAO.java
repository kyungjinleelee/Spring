package com.dao;

import java.util.Arrays;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.dto.DeptDTO;

// @Component("dao")
@Repository("dao")
public class DeptDAO {

	@Autowired
	SqlSessionTemplate session; // SqlSessionTemplate 주입받기
	
	// 목록보기
	public List<DeptDTO> findAll(){
		List<DeptDTO> list = session.selectList("DeptMapper.findAll");
		return list;
	}

	// 저장
	public int deptAdd(DeptDTO dto) {
		int n = session.insert("DeptMapper.deptAdd", dto);
		return n;
	}
	
	// 업데이트
	public int deptUpdate(DeptDTO dto) {
		int n = session.update("DeptMapper.deptUpdate", dto);
		return n;
	}
	
	// 삭제
	public int deptDelete(int deptno) {
		int n = session.delete("DeptMapper.deptDelete", deptno);
		return n;
	}
}
