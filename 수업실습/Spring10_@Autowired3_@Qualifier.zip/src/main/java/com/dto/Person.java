package com.dto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Person { 

	// has a 관계 
	
	String username;
	
	@Autowired
//	@Qualifier(value = "cat1")    ==> cat1(야옹이)가 출력
	@Qualifier(value = "cat2") // ==> cat2(망치)가 출력
	Cat cat;

	public void setUsername(String username) {
		this.username = username;
	}

	@Override
	public String toString() {
		return "Person [username=" + username + ", cat=" + cat + "]";
	}
	
	
}
