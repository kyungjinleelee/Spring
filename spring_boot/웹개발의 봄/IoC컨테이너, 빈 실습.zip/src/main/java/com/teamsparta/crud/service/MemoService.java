package com.teamsparta.crud.service;

import com.teamsparta.crud.dto.MemoRequestDto;
import com.teamsparta.crud.dto.MemoResponseDto;
import com.teamsparta.crud.entity.Memo;
import com.teamsparta.crud.repository.MemoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component  // 빈으로 등록, @Service와 동일함
public class MemoService {

//    @Autowired  // private임에도 불구하고 Autowired 생성자로 외부에서 memoRepository 객체를 주입할 수 있다.
//    private MemoRepository memoRepository; ==> 필드 주입 방법
    private MemoRepository memoRepository;

    @Autowired  // 사실 Autowired 생략 가능한데, 생성자가 '하나만' 선언됐을 경우에 가능하다.
    public MemoService(MemoRepository memoRepository) {
        this.memoRepository = memoRepository;
    }   // ==> 생성자 주입 방법 (객체의 불변성을 지켜줄 수 있기 때문에 의존성주입에서 제일 추천함)

    public MemoResponseDto createMemo(MemoRequestDto requestDto) {
        // RequestDto -> Entity
        Memo memo = new Memo(requestDto);

        // DB 저장
    //  MemoRepository memoRepository = new MemoRepository(jdbcTemplate);
        Memo saveMemo = memoRepository.save(memo);

        // Entity -> ResponseDto
        MemoResponseDto memoResponseDto = new MemoResponseDto(saveMemo);

        return memoResponseDto;
    }

    public List<MemoResponseDto> getMemos() {
        // DB 조회
        return memoRepository.findAll();
    }

    public Long updateMemo(Long id, MemoRequestDto requestDto) {
        // 해당 메모가 DB에 존재하는지 확인
        Memo memo = memoRepository.findById(id);
        if (memo != null) {
            // memo 내용 수정
            memoRepository.update(id, requestDto);

            return id;
        } else {
            throw new IllegalArgumentException("선택한 메모는 존재하지 않습니다.");
        }
    }

    public Long deleteMemo(Long id) {
        // 해당 메모가 DB에 존재하는지 확인
        Memo memo = memoRepository.findById(id);
        if (memo != null) {
            // memo 삭제
            memoRepository.delete(id);

            return id;
        } else {
            throw new IllegalArgumentException("선택한 메모는 존재하지 않습니다.");
        }
    }
}