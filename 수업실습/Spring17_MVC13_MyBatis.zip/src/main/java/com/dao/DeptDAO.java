package com.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.dto.DeptDTO;

@Repository("dao")
public class DeptDAO {
	
	@Autowired
	SqlSessionTemplate session; // ���� ���� �ޱ� 
	// ��Ϻ���
	public List<DeptDTO> findAll(){
		return session.selectList("DeptMapper.findAll");
	}
	
	// �μ� ���
	public int deptAdd(DeptDTO dto) {
		int n = session.insert("DeptMapper.deptAdd", dto);
		return n;
	}
}
