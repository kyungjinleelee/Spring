package com.service;

// target 객체 : 핵심 기능 구현한 빈 
public class UserService {

	// 핵심 처리 메서드
	public String sayEcho() {
		System.out.println("sayEcho");
		// 일부러 예외 발생시키기 
		int n = 0;
		System.out.println(10/n);
		return "hello";
	}
	
	public String callEcho() {
		System.out.println("callEcho");
		return "world";	// 임의의 메서드 
	}
}
