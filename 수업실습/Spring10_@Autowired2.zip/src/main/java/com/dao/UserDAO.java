package com.dao;

import java.util.Arrays;
import java.util.List;

public class UserDAO {

	public List<String> list(){
		return Arrays.asList("홍길동", "이순신");
	}
}
