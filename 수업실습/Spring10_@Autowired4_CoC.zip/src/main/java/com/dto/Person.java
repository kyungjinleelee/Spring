package com.dto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Person { 

	// has a 관계 

	String username;
	
	@Autowired
	Cat cat;	
	// ==> error일 것 같지만, CoC 개념으로 에러가 나지 않는다. (cat1 -> cat으로 바꿔주면)

	public void setUsername(String username) {
		this.username = username;
	}

	@Override
	public String toString() {
		return "Person [username=" + username + ", cat=" + cat + "]";
	}
	
	
}
