package com.service;

public class UserService {
	
	public UserService() {
		System.out.println("UserService 생성자");
	}

	public String mesg() {
		return "Hello";
	}
}
